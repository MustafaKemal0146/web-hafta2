import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type TrackType = 'kick' | 'snare' | 'hihatC' | 'hihatO' | 'bass' | 'cowbell';

export interface Track {
  id: string;
  name: string;
  type: TrackType;
  steps: boolean[];
  volume: number;
  mute: boolean;
  solo: boolean;
}

export interface AppState {
  // Transport
  isPlaying: boolean;
  bpm: number;
  swing: number;
  masterVolume: number;
  currentStep: number;
  
  // Sequencer
  tracks: Track[];
  
  // Synth
  osc1Type: 'sine' | 'square' | 'sawtooth' | 'triangle';
  osc2Type: 'sine' | 'square' | 'sawtooth' | 'triangle';
  attack: number;
  decay: number;
  sustain: number;
  release: number;
  filterCutoff: number;
  filterResonance: number;
  
  // Actions
  togglePlay: () => void;
  setBpm: (bpm: number) => void;
  setSwing: (swing: number) => void;
  setMasterVolume: (volume: number) => void;
  setCurrentStep: (step: number) => void;
  
  toggleStep: (trackId: string, stepIndex: number) => void;
  setTrackVolume: (trackId: string, volume: number) => void;
  toggleTrackMute: (trackId: string) => void;
  toggleTrackSolo: (trackId: string) => void;
  
  setOsc1Type: (type: AppState['osc1Type']) => void;
  setOsc2Type: (type: AppState['osc2Type']) => void;
  setEnvelope: (param: 'attack' | 'decay' | 'sustain' | 'release', value: number) => void;
  setFilter: (param: 'filterCutoff' | 'filterResonance', value: number) => void;
  
  resetPattern: () => void;
}

const initialTracks: Track[] = [
  { 
    id: 'kick', name: 'Kick', type: 'kick', 
    steps: [true, false, false, false, true, false, false, false, true, false, false, false, true, false, false, false], 
    volume: -2, mute: false, solo: false 
  },
  { 
    id: 'snare', name: 'Snare', type: 'snare', 
    steps: [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false], 
    volume: -2, mute: false, solo: false 
  },
  { 
    id: 'hihatC', name: 'Hi-hat (C)', type: 'hihatC', 
    steps: [true, false, true, false, true, false, true, false, true, false, true, false, true, false, true, false], 
    volume: -8, mute: false, solo: false 
  },
  { 
    id: 'hihatO', name: 'Hi-hat (O)', type: 'hihatO', 
    steps: Array(16).fill(false), 
    volume: -8, mute: false, solo: false 
  },
  { 
    id: 'bass', name: 'Bass Hit', type: 'bass', 
    steps: [true, false, false, true, false, false, true, false, false, true, false, false, false, false, false, false], 
    volume: -2, mute: false, solo: false 
  },
  { 
    id: 'cowbell', name: 'Cowbell', type: 'cowbell', 
    steps: Array(16).fill(false), 
    volume: -6, mute: false, solo: false 
  },
];

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      isPlaying: false,
      bpm: 120,
      swing: 0,
      masterVolume: 0,
      currentStep: 0,
      
      tracks: initialTracks,
      
      osc1Type: 'sawtooth',
      osc2Type: 'square',
      attack: 0.05,
      decay: 0.2,
      sustain: 0.5,
      release: 1,
      filterCutoff: 2000,
      filterResonance: 2,
      
      togglePlay: () => set((state) => {
        const nextIsPlaying = !state.isPlaying;
        return { 
          isPlaying: nextIsPlaying,
          currentStep: nextIsPlaying ? state.currentStep : 0
        };
      }),
      setBpm: (bpm) => set({ bpm }),
      setSwing: (swing) => set({ swing }),
      setMasterVolume: (masterVolume) => set({ masterVolume }),
      setCurrentStep: (currentStep) => set({ currentStep }),
      
      toggleStep: (trackId, stepIndex) => set((state) => ({
        tracks: state.tracks.map(t => 
          t.id === trackId 
            ? { ...t, steps: t.steps.map((s, i) => i === stepIndex ? !s : s) }
            : t
        )
      })),
      
      setTrackVolume: (trackId, volume) => set((state) => ({
        tracks: state.tracks.map(t => t.id === trackId ? { ...t, volume } : t)
      })),
      
      toggleTrackMute: (trackId) => set((state) => ({
        tracks: state.tracks.map(t => t.id === trackId ? { ...t, mute: !t.mute } : t)
      })),
      
      toggleTrackSolo: (trackId) => set((state) => {
        const isCurrentlySolo = state.tracks.find(t => t.id === trackId)?.solo;
        return {
          tracks: state.tracks.map(t => t.id === trackId ? { ...t, solo: !isCurrentlySolo } : t)
        };
      }),
      
      setOsc1Type: (osc1Type) => set({ osc1Type }),
      setOsc2Type: (osc2Type) => set({ osc2Type }),
      setEnvelope: (param, value) => set({ [param]: value }),
      setFilter: (param, value) => set({ [param]: value }),
      
      resetPattern: () => set((state) => ({
        tracks: state.tracks.map(t => ({ ...t, steps: Array(16).fill(false) }))
      })),
    }),
    {
      name: 'beatlab-storage-v3',
      partialize: (state) => ({
        tracks: state.tracks,
        bpm: state.bpm,
        swing: state.swing,
        osc1Type: state.osc1Type,
        osc2Type: state.osc2Type,
        attack: state.attack,
        decay: state.decay,
        sustain: state.sustain,
        release: state.release,
        filterCutoff: state.filterCutoff,
        filterResonance: state.filterResonance,
      }),
    }
  )
);
