import * as Tone from 'tone';
import { useStore, TrackType } from '../store/useStore';

class AudioEngine {
  private initialized = false;
  
  // Master
  private masterVolume!: Tone.Volume;
  private masterCompressor!: Tone.Compressor;
  
  // Sequencer Instruments
  private kick!: Tone.MembraneSynth;
  private snare!: Tone.NoiseSynth;
  private hihatC!: Tone.MetalSynth;
  private hihatO!: Tone.MetalSynth;
  private cowbell!: Tone.MetalSynth;
  private bass!: Tone.FMSynth;
  
  // Track Channels
  private channels: Record<TrackType, Tone.Channel> = {} as any;
  
  // Synth
  private synthOsc1!: Tone.PolySynth<Tone.Synth>;
  private synthOsc2!: Tone.PolySynth<Tone.Synth>;
  private synthFilter!: Tone.Filter;
  
  // Loop
  private loop!: Tone.Sequence;
  
  private initPromise: Promise<void> | null = null;
  
  public async init() {
    if (this.initialized) return;
    if (this.initPromise) return this.initPromise;
    
    this.initPromise = (async () => {
      await Tone.start();
      
      // Master Chain
      this.masterVolume = new Tone.Volume(-6).toDestination();
      this.masterCompressor = new Tone.Compressor({
        threshold: -24,
        ratio: 4,
        attack: 0.003,
        release: 0.25
      }).connect(this.masterVolume);
      
      // Channels
      const trackTypes: TrackType[] = ['kick', 'snare', 'hihatC', 'hihatO', 'bass', 'cowbell'];
      trackTypes.forEach(type => {
        this.channels[type] = new Tone.Channel().connect(this.masterCompressor);
      });
      
      // Instruments
      this.kick = new Tone.MembraneSynth({
        pitchDecay: 0.05,
        octaves: 4,
        oscillator: { type: 'sine' },
        envelope: { attack: 0.001, decay: 0.4, sustain: 0.01, release: 1.4 }
      }).connect(this.channels.kick);
      
      this.snare = new Tone.NoiseSynth({
        noise: { type: 'white' },
        envelope: { attack: 0.005, decay: 0.2, sustain: 0 }
      }).connect(this.channels.snare);
      
      this.hihatC = new Tone.MetalSynth({
        envelope: { attack: 0.001, decay: 0.1, release: 0.01 },
        harmonicity: 5.1,
        modulationIndex: 32,
        resonance: 4000,
        octaves: 1.5
      }).connect(this.channels.hihatC);
      this.hihatC.frequency.value = 200;
      
      this.hihatO = new Tone.MetalSynth({
        envelope: { attack: 0.001, decay: 0.4, release: 0.1 },
        harmonicity: 5.1,
        modulationIndex: 32,
        resonance: 4000,
        octaves: 1.5
      }).connect(this.channels.hihatO);
      this.hihatO.frequency.value = 200;
      
      this.cowbell = new Tone.MetalSynth({
        envelope: { attack: 0.001, decay: 0.1, release: 0.01 },
        harmonicity: 0.5,
        modulationIndex: 20,
        resonance: 8000,
        octaves: 0.5
      }).connect(this.channels.cowbell);
      this.cowbell.frequency.value = 800;
      
      this.bass = new Tone.FMSynth({
        harmonicity: 1,
        modulationIndex: 1,
        oscillator: { type: 'square' },
        envelope: { attack: 0.01, decay: 0.2, sustain: 0.2, release: 0.5 },
        modulation: { type: 'square' },
        modulationEnvelope: { attack: 0.01, decay: 0.2, sustain: 0.2, release: 0.5 }
      }).connect(this.channels.bass);
      
      // Synth Section
      this.synthFilter = new Tone.Filter(2000, 'lowpass').connect(this.masterCompressor);
      
      this.synthOsc1 = new Tone.PolySynth(Tone.Synth, {
        oscillator: { type: 'sawtooth' },
        envelope: { attack: 0.05, decay: 0.2, sustain: 0.5, release: 1 }
      }).connect(this.synthFilter);
      
      this.synthOsc2 = new Tone.PolySynth(Tone.Synth, {
        oscillator: { type: 'square' },
        envelope: { attack: 0.05, decay: 0.2, sustain: 0.5, release: 1 }
      }).connect(this.synthFilter);
      
      // Loop
      const steps = Array.from({ length: 16 }, (_, i) => i);
      this.loop = new Tone.Sequence(
        (time, step) => {
          const state = useStore.getState();
          
          // Schedule UI update
          Tone.getDraw().schedule(() => {
            if (useStore.getState().isPlaying) {
              state.setCurrentStep(step);
            }
          }, time);
          
          // Play tracks
          state.tracks.forEach(track => {
            if (track.steps[step] && !track.mute) {
              // Check solo
              const hasSolo = state.tracks.some(t => t.solo);
              if (hasSolo && !track.solo) return;
              
              switch (track.type) {
                case 'kick':
                  this.kick.triggerAttackRelease('C1', '8n', time);
                  break;
                case 'snare':
                  this.snare.triggerAttackRelease('16n', time);
                  break;
                case 'hihatC':
                  this.hihatC.triggerAttackRelease('32n', time, 0.5);
                  break;
                case 'hihatO':
                  this.hihatO.triggerAttackRelease('8n', time, 0.5);
                  break;
                case 'bass':
                  this.bass.triggerAttackRelease('C2', '16n', time);
                  break;
                case 'cowbell':
                  this.cowbell.triggerAttackRelease('16n', time, 0.6);
                  break;
              }
            }
          });
        },
        steps,
        '16n'
      );
      
      this.initialized = true;
      this.syncWithState();
    })();
    
    return this.initPromise;
  }
  
  public syncWithState() {
    if (!this.initialized) return;
    
    const state = useStore.getState();
    
    // Transport
    if (Math.abs((Tone.getTransport().bpm.value as number) - state.bpm) > 0.1) {
      Tone.getTransport().bpm.value = state.bpm;
    }
    
    if (Tone.getTransport().swing !== state.swing / 100) {
      Tone.getTransport().swing = state.swing / 100;
    }

    if (Math.abs((this.masterVolume.volume.value as number) - state.masterVolume) > 0.1) {
      this.masterVolume.volume.value = state.masterVolume;
    }
    
    if (state.isPlaying) {
      if (Tone.getTransport().state !== 'started') {
        Tone.getTransport().start();
      }
      if (this.loop.state !== 'started') {
        this.loop.start(0);
      }
    } else {
      if (Tone.getTransport().state !== 'stopped') {
        Tone.getTransport().stop();
        this.loop.stop();
      }
    }
    
    // Tracks
    state.tracks.forEach(track => {
      if (this.channels[track.type]) {
        if (Math.abs((this.channels[track.type].volume.value as number) - track.volume) > 0.1) {
          this.channels[track.type].volume.value = track.volume;
        }
      }
    });
    
    // Synth - Only update if changed to avoid timeline overhead
    const osc1 = this.synthOsc1.get() as any;
    if (osc1.oscillator.type !== state.osc1Type) {
      this.synthOsc1.set({ oscillator: { type: state.osc1Type } });
    }
    
    const osc2 = this.synthOsc2.get() as any;
    if (osc2.oscillator.type !== state.osc2Type) {
      this.synthOsc2.set({ oscillator: { type: state.osc2Type } });
    }

    // Envelope and Filter
    this.synthOsc1.set({
      envelope: {
        attack: state.attack,
        decay: state.decay,
        sustain: state.sustain,
        release: state.release
      }
    });
    
    this.synthOsc2.set({
      envelope: {
        attack: state.attack,
        decay: state.decay,
        sustain: state.sustain,
        release: state.release
      }
    });
    
    if (Math.abs((this.synthFilter.frequency.value as number) - state.filterCutoff) > 1) {
      this.synthFilter.frequency.value = state.filterCutoff;
    }
    if (Math.abs((this.synthFilter.Q.value as number) - state.filterResonance) > 0.1) {
      this.synthFilter.Q.value = state.filterResonance;
    }
  }
  
  public triggerSynthAttack(note: string) {
    if (!this.initialized) return;
    this.synthOsc1.triggerAttack(note);
    this.synthOsc2.triggerAttack(note);
  }
  
  public triggerSynthRelease(note: string) {
    if (!this.initialized) return;
    this.synthOsc1.triggerRelease(note);
    this.synthOsc2.triggerRelease(note);
  }
}

export const engine = new AudioEngine();

// Subscribe to store changes to keep engine in sync
useStore.subscribe((state, prevState) => {
  if (
    state.isPlaying !== prevState.isPlaying ||
    state.bpm !== prevState.bpm ||
    state.swing !== prevState.swing ||
    state.masterVolume !== prevState.masterVolume ||
    state.tracks !== prevState.tracks ||
    state.osc1Type !== prevState.osc1Type ||
    state.osc2Type !== prevState.osc2Type ||
    state.attack !== prevState.attack ||
    state.decay !== prevState.decay ||
    state.sustain !== prevState.sustain ||
    state.release !== prevState.release ||
    state.filterCutoff !== prevState.filterCutoff ||
    state.filterResonance !== prevState.filterResonance
  ) {
    engine.syncWithState();
  }
});
