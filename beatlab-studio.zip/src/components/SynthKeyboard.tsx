import React, { useEffect, useState } from 'react';
import { engine } from '../audio/engine';

const KEY_MAP: Record<string, string> = {
  'a': 'C4', 'w': 'C#4', 's': 'D4', 'e': 'D#4', 'd': 'E4',
  'f': 'F4', 't': 'F#4', 'g': 'G4', 'y': 'G#4', 'h': 'A4',
  'u': 'A#4', 'j': 'B4', 'k': 'C5', 'o': 'C#5', 'l': 'D5',
  'p': 'D#5', ';': 'E5', '\'': 'F5'
};

const NOTES = [
  { note: 'C4', isBlack: false }, { note: 'C#4', isBlack: true },
  { note: 'D4', isBlack: false }, { note: 'D#4', isBlack: true },
  { note: 'E4', isBlack: false },
  { note: 'F4', isBlack: false }, { note: 'F#4', isBlack: true },
  { note: 'G4', isBlack: false }, { note: 'G#4', isBlack: true },
  { note: 'A4', isBlack: false }, { note: 'A#4', isBlack: true },
  { note: 'B4', isBlack: false },
  { note: 'C5', isBlack: false }, { note: 'C#5', isBlack: true },
  { note: 'D5', isBlack: false }, { note: 'D#5', isBlack: true },
  { note: 'E5', isBlack: false },
  { note: 'F5', isBlack: false }
];

export const SynthKeyboard: React.FC = () => {
  const [activeNotes, setActiveNotes] = useState<Set<string>>(new Set());

  useEffect(() => {
    const handleKeyDown = async (e: KeyboardEvent) => {
      if (e.repeat) return;
      const note = KEY_MAP[e.key.toLowerCase()];
      if (note) {
        await engine.init();
        engine.triggerSynthAttack(note);
        setActiveNotes(prev => new Set(prev).add(note));
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const note = KEY_MAP[e.key.toLowerCase()];
      if (note) {
        engine.triggerSynthRelease(note);
        setActiveNotes(prev => {
          const next = new Set(prev);
          next.delete(note);
          return next;
        });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const handleMouseDown = async (note: string) => {
    await engine.init();
    engine.triggerSynthAttack(note);
    setActiveNotes(prev => new Set(prev).add(note));
  };

  const handleMouseUp = (note: string) => {
    engine.triggerSynthRelease(note);
    setActiveNotes(prev => {
      const next = new Set(prev);
      next.delete(note);
      return next;
    });
  };

  const handleMouseLeave = (note: string) => {
    if (activeNotes.has(note)) {
      handleMouseUp(note);
    }
  };

  return (
    <div className="flex justify-center p-8 bg-zinc-900 border-t border-zinc-800">
      <div className="relative flex h-48 select-none">
        {NOTES.map(({ note, isBlack }) => {
          const isActive = activeNotes.has(note);
          const keyLabel = Object.keys(KEY_MAP).find(k => KEY_MAP[k] === note)?.toUpperCase();
          
          if (isBlack) {
            return (
              <div
                key={note}
                onMouseDown={() => handleMouseDown(note)}
                onMouseUp={() => handleMouseUp(note)}
                onMouseLeave={() => handleMouseLeave(note)}
                className={`z-10 w-10 h-32 -mx-5 rounded-b-md border border-zinc-950 cursor-pointer transition-colors relative flex justify-center ${
                  isActive ? 'bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.5)]' : 'bg-zinc-800 hover:bg-zinc-700'
                }`}
              >
                <div className="absolute bottom-2 text-[10px] font-mono text-zinc-500 pointer-events-none">
                  {keyLabel}
                </div>
              </div>
            );
          }

          return (
            <div
              key={note}
              onMouseDown={() => handleMouseDown(note)}
              onMouseUp={() => handleMouseUp(note)}
              onMouseLeave={() => handleMouseLeave(note)}
              className={`w-14 h-full border border-zinc-300 rounded-b-md cursor-pointer transition-colors relative flex flex-col justify-end pb-4 ${
                isActive ? 'bg-emerald-200 shadow-[inset_0_0_15px_rgba(16,185,129,0.3)]' : 'bg-zinc-100 hover:bg-white'
              }`}
            >
              <div className="text-center text-xs font-mono text-zinc-400 pointer-events-none">
                {keyLabel}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
