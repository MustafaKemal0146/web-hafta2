import React from 'react';
import { Play, Square, RotateCcw } from 'lucide-react';
import { useStore } from '../store/useStore';
import { engine } from '../audio/engine';

export const TransportBar: React.FC = () => {
  const { isPlaying, togglePlay, bpm, setBpm, swing, setSwing, masterVolume, setMasterVolume, resetPattern } = useStore();

  const handlePlayToggle = async () => {
    await engine.init();
    togglePlay();
  };

  return (
    <div className="flex flex-wrap items-center gap-4 p-4 bg-zinc-900 border-b border-zinc-800 text-zinc-100">
      <div className="flex items-center gap-2">
        <button
          onClick={handlePlayToggle}
          className={`p-3 rounded-xl transition-colors ${isPlaying ? 'bg-emerald-500 text-zinc-950 hover:bg-emerald-400' : 'bg-zinc-800 hover:bg-zinc-700 text-emerald-500'}`}
        >
          {isPlaying ? <Square size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" />}
        </button>
        <button
          onClick={resetPattern}
          className="p-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-zinc-100 transition-colors"
          title="Reset Pattern"
        >
          <RotateCcw size={20} />
        </button>
      </div>

      <div className="flex items-center gap-6 ml-4">
        <div className="flex flex-col gap-1">
          <label className="text-xs font-mono text-zinc-500 uppercase tracking-wider">BPM</label>
          <div className="flex items-center gap-2">
            <input
              type="range"
              min="60"
              max="180"
              value={bpm}
              onChange={(e) => setBpm(Number(e.target.value))}
              className="w-24 accent-emerald-500"
            />
            <span className="font-mono text-sm w-8 text-right">{bpm}</span>
          </div>
        </div>

        <div className="flex flex-col gap-1">
          <label className="text-xs font-mono text-zinc-500 uppercase tracking-wider">Swing</label>
          <div className="flex items-center gap-2">
            <input
              type="range"
              min="0"
              max="100"
              value={swing}
              onChange={(e) => setSwing(Number(e.target.value))}
              className="w-24 accent-emerald-500"
            />
            <span className="font-mono text-sm w-8 text-right">{swing}%</span>
          </div>
        </div>

        <div className="flex flex-col gap-1">
          <label className="text-xs font-mono text-zinc-500 uppercase tracking-wider">Master</label>
          <div className="flex items-center gap-2">
            <input
              type="range"
              min="-60"
              max="20"
              value={masterVolume}
              onChange={(e) => setMasterVolume(Number(e.target.value))}
              className="w-24 accent-emerald-500"
            />
            <span className="font-mono text-sm w-12 text-right">{masterVolume}dB</span>
          </div>
        </div>
      </div>
      
      <div className="ml-auto">
        <h1 className="text-xl font-bold tracking-tight text-zinc-400">
          BEAT<span className="text-emerald-500">LAB</span> STUDIO
        </h1>
      </div>
    </div>
  );
};
