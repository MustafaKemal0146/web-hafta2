import React from 'react';
import { useStore } from '../store/useStore';

export const SynthControls: React.FC = () => {
  const {
    osc1Type, setOsc1Type,
    osc2Type, setOsc2Type,
    attack, decay, sustain, release, setEnvelope,
    filterCutoff, filterResonance, setFilter
  } = useStore();

  return (
    <div className="flex flex-wrap gap-8 p-6 bg-zinc-950 border-t border-zinc-800 text-zinc-300">
      
      {/* Oscillators */}
      <div className="flex flex-col gap-4">
        <h3 className="text-xs font-bold tracking-widest text-zinc-500 uppercase">Oscillators</h3>
        <div className="flex gap-4">
          <div className="flex flex-col gap-2 bg-zinc-900 p-3 rounded-lg border border-zinc-800">
            <label className="text-[10px] uppercase text-zinc-500">OSC 1</label>
            <select 
              value={osc1Type} 
              onChange={(e) => setOsc1Type(e.target.value as any)}
              className="bg-zinc-950 border border-zinc-800 rounded p-1 text-sm outline-none focus:border-emerald-500"
            >
              <option value="sine">Sine</option>
              <option value="square">Square</option>
              <option value="sawtooth">Sawtooth</option>
              <option value="triangle">Triangle</option>
            </select>
          </div>
          <div className="flex flex-col gap-2 bg-zinc-900 p-3 rounded-lg border border-zinc-800">
            <label className="text-[10px] uppercase text-zinc-500">OSC 2</label>
            <select 
              value={osc2Type} 
              onChange={(e) => setOsc2Type(e.target.value as any)}
              className="bg-zinc-950 border border-zinc-800 rounded p-1 text-sm outline-none focus:border-emerald-500"
            >
              <option value="sine">Sine</option>
              <option value="square">Square</option>
              <option value="sawtooth">Sawtooth</option>
              <option value="triangle">Triangle</option>
            </select>
          </div>
        </div>
      </div>

      {/* Filter */}
      <div className="flex flex-col gap-4">
        <h3 className="text-xs font-bold tracking-widest text-zinc-500 uppercase">Filter</h3>
        <div className="flex gap-4 bg-zinc-900 p-3 rounded-lg border border-zinc-800">
          <div className="flex flex-col gap-2 w-24">
            <div className="flex justify-between">
              <label className="text-[10px] uppercase text-zinc-500">Cutoff</label>
              <span className="text-[10px] font-mono">{Math.round(filterCutoff)}Hz</span>
            </div>
            <input 
              type="range" min="20" max="10000" step="10"
              value={filterCutoff} 
              onChange={(e) => setFilter('filterCutoff', Number(e.target.value))}
              className="accent-emerald-500"
            />
          </div>
          <div className="flex flex-col gap-2 w-24">
            <div className="flex justify-between">
              <label className="text-[10px] uppercase text-zinc-500">Res</label>
              <span className="text-[10px] font-mono">{filterResonance.toFixed(1)}</span>
            </div>
            <input 
              type="range" min="0" max="20" step="0.1"
              value={filterResonance} 
              onChange={(e) => setFilter('filterResonance', Number(e.target.value))}
              className="accent-emerald-500"
            />
          </div>
        </div>
      </div>

      {/* Envelope */}
      <div className="flex flex-col gap-4">
        <h3 className="text-xs font-bold tracking-widest text-zinc-500 uppercase">Envelope</h3>
        <div className="flex gap-4 bg-zinc-900 p-3 rounded-lg border border-zinc-800">
          <div className="flex flex-col gap-2 w-20">
            <div className="flex justify-between">
              <label className="text-[10px] uppercase text-zinc-500">A</label>
              <span className="text-[10px] font-mono">{attack.toFixed(2)}</span>
            </div>
            <input 
              type="range" min="0.01" max="2" step="0.01"
              value={attack} 
              onChange={(e) => setEnvelope('attack', Number(e.target.value))}
              className="accent-emerald-500"
            />
          </div>
          <div className="flex flex-col gap-2 w-20">
            <div className="flex justify-between">
              <label className="text-[10px] uppercase text-zinc-500">D</label>
              <span className="text-[10px] font-mono">{decay.toFixed(2)}</span>
            </div>
            <input 
              type="range" min="0.01" max="2" step="0.01"
              value={decay} 
              onChange={(e) => setEnvelope('decay', Number(e.target.value))}
              className="accent-emerald-500"
            />
          </div>
          <div className="flex flex-col gap-2 w-20">
            <div className="flex justify-between">
              <label className="text-[10px] uppercase text-zinc-500">S</label>
              <span className="text-[10px] font-mono">{sustain.toFixed(2)}</span>
            </div>
            <input 
              type="range" min="0" max="1" step="0.01"
              value={sustain} 
              onChange={(e) => setEnvelope('sustain', Number(e.target.value))}
              className="accent-emerald-500"
            />
          </div>
          <div className="flex flex-col gap-2 w-20">
            <div className="flex justify-between">
              <label className="text-[10px] uppercase text-zinc-500">R</label>
              <span className="text-[10px] font-mono">{release.toFixed(2)}</span>
            </div>
            <input 
              type="range" min="0.01" max="5" step="0.01"
              value={release} 
              onChange={(e) => setEnvelope('release', Number(e.target.value))}
              className="accent-emerald-500"
            />
          </div>
        </div>
      </div>

    </div>
  );
};
