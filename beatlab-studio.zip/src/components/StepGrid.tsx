import React from 'react';
import { useStore } from '../store/useStore';
import { engine } from '../audio/engine';

export const StepGrid: React.FC = () => {
  const { tracks, currentStep, toggleStep, toggleTrackMute, toggleTrackSolo, setTrackVolume } = useStore();

  const handleStepClick = async (trackId: string, stepIndex: number) => {
    await engine.init();
    toggleStep(trackId, stepIndex);
  };

  return (
    <div className="flex flex-col gap-1 p-4 bg-zinc-950 overflow-x-auto">
      <div className="flex items-center mb-2">
        <div className="w-48 shrink-0"></div>
        <div className="flex flex-1 gap-1">
          {Array.from({ length: 16 }).map((_, i) => (
            <div
              key={i}
              className={`flex-1 h-2 rounded-full mx-0.5 transition-colors ${
                currentStep === i ? 'bg-emerald-500' : 'bg-zinc-800'
              }`}
            />
          ))}
        </div>
      </div>

      {tracks.map((track) => (
        <div key={track.id} className="flex items-center gap-4 group">
          <div className="w-48 shrink-0 flex items-center justify-between bg-zinc-900 rounded-lg p-2 border border-zinc-800">
            <span className="font-mono text-sm text-zinc-300 truncate w-20">{track.name}</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => toggleTrackMute(track.id)}
                className={`w-6 h-6 rounded text-xs font-bold transition-colors ${
                  track.mute ? 'bg-red-500/20 text-red-500 border border-red-500/50' : 'bg-zinc-800 text-zinc-500 hover:bg-zinc-700'
                }`}
              >
                M
              </button>
              <button
                onClick={() => toggleTrackSolo(track.id)}
                className={`w-6 h-6 rounded text-xs font-bold transition-colors ${
                  track.solo ? 'bg-yellow-500/20 text-yellow-500 border border-yellow-500/50' : 'bg-zinc-800 text-zinc-500 hover:bg-zinc-700'
                }`}
              >
                S
              </button>
            </div>
          </div>

          <div className="flex flex-1 gap-1">
            {track.steps.map((isActive, i) => (
              <button
                key={i}
                onClick={() => handleStepClick(track.id, i)}
                className={`flex-1 aspect-square rounded-md transition-all duration-75 border ${
                  isActive
                    ? 'bg-emerald-500 border-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.5)]'
                    : i % 4 === 0
                    ? 'bg-zinc-800 border-zinc-700 hover:bg-zinc-700'
                    : 'bg-zinc-900 border-zinc-800 hover:bg-zinc-800'
                } ${currentStep === i && !isActive ? 'bg-zinc-700 border-zinc-600' : ''}`}
              />
            ))}
          </div>
          
          <div className="w-24 shrink-0 flex items-center opacity-0 group-hover:opacity-100 transition-opacity">
            <input
              type="range"
              min="-60"
              max="20"
              value={track.volume}
              onChange={(e) => setTrackVolume(track.id, Number(e.target.value))}
              className="w-full accent-zinc-500"
            />
          </div>
        </div>
      ))}
    </div>
  );
};
