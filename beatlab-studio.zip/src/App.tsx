import React from 'react';
import { TransportBar } from './components/TransportBar';
import { StepGrid } from './components/StepGrid';
import { SynthControls } from './components/SynthControls';
import { SynthKeyboard } from './components/SynthKeyboard';

export default function App() {
  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-emerald-500/30">
      <TransportBar />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top Panel: Drum Sequencer */}
        <div className="flex-1 overflow-y-auto border-b border-zinc-800">
          <div className="max-w-7xl mx-auto w-full">
            <StepGrid />
          </div>
        </div>

        {/* Bottom Panel: Synth Section */}
        <div className="flex-shrink-0 bg-zinc-950">
          <div className="max-w-7xl mx-auto w-full">
            <SynthControls />
            <SynthKeyboard />
          </div>
        </div>
      </main>
    </div>
  );
}
